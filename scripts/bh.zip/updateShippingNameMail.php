<?php
/**
 * Update transactional mail config_shipping descriptions and dispatch description.
 * Expected columns:
 *      description
 *      dispatch_description
 *      frontend_code
 *      brand
 *      locale
 */
class updateShippingNameMail extends Script
{
    public function getModel()
    {
        return (new FfcModel())
            ->addFilenames('shipping.csv', 'shippingMail.sql')
            ->addStatement('UPDATE config_shipping SET `name`="~name~" ' .
                            'WHERE `frontend_code`="~frontend_code~" AND `brand`="~brand~" AND locale="~locale~";')
        ;
    }
}
