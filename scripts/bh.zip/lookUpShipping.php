<?php
/**
 * Update transactional mail config_shipping descriptions and dispatch description.
 * Expected columns:
 *      description
 *      dispatch_description
 *      frontend_code
 *      brand
 *      locale
 */
class lookUpShipping extends Script
{
    public function getModel()
    {
        return (new FfcModel())
            ->addFilenames('shipping.csv', 'shipping.sql')
            ->setPrefix('SELECT brand,locale,frontend_code,description,dispatch_description FROM config_shipping WHERE ')
            ->addStatement('(`frontend_code`="~frontend_code~" AND `brand`="~brand~" AND locale="~locale~")')
            ->addGlue(' OR ')
        ;
    }
}
