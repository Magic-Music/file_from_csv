<?php
/**
 * Output XML to generate gift certificates in demandware
 *
 * Expected columns:
 *
 * - sku
 * - price
 *
 * Set pricebook name and currency in class properties
 */

class createPricebook extends Script
{
    private $pricebookName = 'misspap-uk-au-aud-list';
    private $currency = 'AUD';

    public function getModel()
    {
        return (new FfcModel())

            ->addFilenames('giftcert.csv', 'giftcert.xml')

            ->setPrefix(<<<XML_OPEN
                <?xml version="1.0" encoding="utf-8"?>
                <pricebooks xmlns="http://www.demandware.com/xml/impex/pricebook/2006-10-31">
                    <pricebook>
                        <header pricebook-id="~pricebook~">
                            <currency>~currency~</currency>
                            <display-name xml:lang="x-default">~currency~ list Prices</display-name>
                            <description>Price book last updated at ~dmydatetime~</description>
                            <online-flag>true</online-flag>
                        </header>
                XML_OPEN)

            ->addStatement(<<<XML_BODY
                        <price-table product-id="~sku~">
                            <amount quantity="1">~price~</amount>
                        </price-table>
                XML_BODY)

            ->setSuffix(<<<XML_CLOSE
                    </pricebook>
                </pricebooks>
                XML_CLOSE)

            ->noNewLine()
        ;
    }

    public function pricebook()
    {
        return $this->pricebookName;
    }

    public function currency()
    {
        return $this->currency;
    }
}
