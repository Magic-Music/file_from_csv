<?php
/**
 * Create Demandware XML Import file to add customers to a Static Customer Group
 *
 * Set the Group Id in the properties
 */

class extendLoyaltyDate extends Script
{
    private $emailField='~email~';
    private $input='emails.csv';
    private $output='extendloyalty.xml';
    private $expireDate="2020-11-01";

    public function getModel()
    {
        return (new FfcModel())

            ->addFilenames($this->input, $this->output)

            ->setPrefix(<<<XML_OPEN
                <?xml version="1.0" encoding="utf-8"?>
                <customers xmlns="http://www.demandware.com/xml/impex/customer/2006-10-31">
                XML_OPEN)

            ->addStatement(<<<XML_BODY
                    <customer>
                        <credentials>
                            <login>~emailField~</login>
                            <enabled-flag>true</enabled-flag>
                        </credentials>
                        <profile>
                            <custom-attributes>
                                <custom-attribute attribute-id="loyaltyExpirationDate">{$this->expireDate}</custom-attribute>
                            </custom-attributes>
                        </profile>
                    </customer>
                XML_BODY)

            ->setSuffix('</customers>')

            ->noNewLine()
        ;
    }

    public function emailField()
    {
        return $this->emailField;
    }

    public function groupId()
    {
        return $this->groupId;
    }
}
