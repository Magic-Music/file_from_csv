<?php
class lookUpMissingShipping extends Script
{
    public function getModel()
    {
        return (new FfcModel())
            ->addFilenames('shipping.csv', 'shipping.sql')
            ->setPrefix('drop temporary table tmp_config_shipping; ' .
                'create temporary table tmp_config_shipping (frontend_code varchar(255), brand varchar(255), locale varchar(255)); ' .
                'insert into tmp_config_shipping (frontend_code, brand, locale) values ')
            ->addStatement('("~frontend_code~", "~brand~", "~locale~")')
            ->addGlue(', ')
            ->setSuffix('; select t.*, c.frontend_code from tmp_config_shipping as t left join config_shipping as c on c.frontend_code = t.frontend_code ' .
                'and c.brand = t.brand and c.locale = t.locale where c.frontend_code is null;')
        ;
    }
}