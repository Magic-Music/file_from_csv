<?php
/**
 * Create Demandware XML Import file to add customers to a Static Customer Group
 *
 * Set the Group Id in the properties
 */

class createCustomersOnDw extends Script
{
    private $emailField='email';
    private $input='Andrew_Golden_KM.csv';
    private $output='Andrew_Golden_KM_create.xml';

    public function getModel()
    {
        return (new FfcModel())

            ->addFilenames($this->input, $this->output)

            ->setPrefix(<<<XML_OPEN
                <?xml version="1.0" encoding="utf-8"?>
                <customers xmlns="http://www.demandware.com/xml/impex/customer/2006-10-31">
                XML_OPEN)

            ->addStatement(<<<XML_BODY
                    <customer>
                        <credentials>
                            <login>~emailField~</login>
                            <password encrypted="false">FaKePaSsWoRd</password>
                            <enabled-flag>true</enabled-flag>
                            <password-question/>
                            <password-answer/>
                        </credentials>
                        <profile>
                            <salutation/>
                            <first-name>~firstname~</first-name>
                            <second-name/>
                            <last-name>~lastname~</last-name>
                            <suffix/>
                            <company-name/>
                            <job-title/>
                            <email>~emailField~</email>
                            <phone-home/>
                            <creation-date>~iso8601~</creation-date>
                            <preferred-locale/>
                            <custom-attributes>
                                <custom-attribute attribute-id="is3rdPartySubscribed">false</custom-attribute>
                                <custom-attribute attribute-id="isEmailSubscribed">false</custom-attribute>
                                <custom-attribute attribute-id="isPasswordMigrated">true</custom-attribute>
                                <custom-attribute attribute-id="isPostalSubscribed">false</custom-attribute>
                                <custom-attribute attribute-id="isSMSSubscribed">false</custom-attribute>
                            </custom-attributes>
                        </profile>
                        <addresses>
                            <address address-id="Sandbach" preferred="true">
                                <salutation/>
                                <title/>
                                <first-name>~firstname~</first-name>
                                <second-name/>
                                <last-name>~lastname~</last-name>
                                <suffix/>
                                <company-name/>
                                <job-title/>
                                <address1>12 Morgan Road</address1>
                                <address2/>
                                <suite/>
                                <postbox/>
                                <city>Sandbach</city>
                                <postal-code>CW11 3EQ</postal-code>
                                <state-code/>
                                <country-code>GB</country-code>
                                <phone>07414212221</phone>
                            </address>
                        </addresses>
                        <note/>
                    </customer>
                XML_BODY)

            ->setSuffix('</customers>')

            ->noNewLine()
        ;
    }

    public function firstname($row)
    {
        return $this->getName($row,0);
    }

    public function lastname($row)
    {
        return $this->getName($row,1);
    }

    public function emailField()
    {
        return "~".$this->emailField."~";
    }

    private function getName($row,$index)
    {
        $chunks=explode('@',$row[$this->emailField]);
        $namePart=$chunks[0];
        $names=explode('.',$namePart);

        if($names[$index] ?? null) {
            return $names[$index];
        } else {
            return $names[0];
        }
    }
}
