<?php
/**

 */

class createShippingCoda extends Script
{
    private $language = 'en';

    public function getModel()
    {
        return (new FfcModel())
            ->addFilenames('shipping.csv', 'shippingCoda.sql')
            
            ->addStatement("INSERT IGNORE INTO deliveryMethod (`brand`,`locale`,`frontend_code`,`name`,`description`) " .
                            "values ('~brand~','~locale~','~frontend_code~','~name~','~name~');")
        ;
    }

    public function language()
    {
        return $this->language;
    }
}
