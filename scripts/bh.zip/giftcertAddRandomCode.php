<?php
/**
 * Adds a random code colum to a giftcert csv
 */

class giftcertAddRandomCode extends Script
{
    private $codePrefix = "KMVIP";
    private static $number;

    public function getModel()
    {
        return (new FfcModel())

            ->addFilenames('KMupload.csv', 'KMupload_codes.csv') //Input file, Output file.

            ->setPrefix('customer_email_address,customer_name,giftcert_value,giftcert_message,site_id,locale,currency,sender_name,expiry_days,campaign_name,campaign_prefix,code')

            ->addStatement('~customer_email_address~,~customer_name~,~giftcert_value~,~giftcert_message~,~site_id~,' .
                            '~locale~,~currency~,~sender_name~,~expiry_days~,~campaign_name~,~campaign_prefix~,~randomcode~')

        ;
    }

    public function randomcode()
    {
        if(!self::$number) {
            self::$number=rand(11111111111,99999999999);
        }
        self::$number += rand(10,100);
        $number = substr((string)self::$number,-11);
        return $this->codePrefix . $number;
    }

}
