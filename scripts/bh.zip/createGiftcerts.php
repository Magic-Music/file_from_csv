<?php
/**
 * Output XML to generate gift certificates in demandware
 *
 * *****  NOTE - The file must be re-encoded as UTF-8 (no signature) e.g. in EmEditor before it will run in DemandWare! *****
 *
 * Expected columns:
 *
 *  gc-id  (the giftcert voucher code)
 *  customer_email_address
 *
 */

class createGiftcerts extends Script
{
    private $input = 'laybuy.csv';
    private $output = 'laybuy_giftcerts.xml';
    private $brand = "Boohoo";
    private $message = "Hey there. Thanks for being part of Laybuy Day! We've now credited the value of one of your payments to your boohoo account. ";
    private $description = "Laybuy Day";
    private $codePrefix = "LAYBUY072020";
    private $endDate = "2021-07-13T00:00:00.000+0000";
    private $currency = 'GBP';
    private $locale = 'en_GB';
    private $siteId = 'boohoo-UK';

    public function getModel()
    {
        return (new FfcModel())

            ->addFilenames($this->input, $this->output)

            ->setPrefix(<<<XML_OPEN
                <?xml version="1.0" encoding="utf-8"?>
                    <gift-certificates xmlns:xml="http://www.w3.org/XML/1998/namespace" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns="http://www.demandware.com/xml/impex/giftcertificate/2007-02-28"
                        xsi:schemaLocation="http://www.demandware.com/xml/impex/giftcertificate/2007-02-28 schema.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
                XML_OPEN)

            ->addStatement(<<<XML_BODY
                        <gift-certificate gc-id="~randomcode~">
                            <create-date>~timestamp~</create-date>
                            <recipient-name>~email_address~</recipient-name>
                            <recipient-email>~email_address~</recipient-email>
                            <sender-name>~brand~</sender-name>
                            <message>~certMessage~</message>
                            <description>~certDescription~</description>
                            <enabled-flag>1</enabled-flag>
                            <status>ISSUED</status>
                            <currency>~staticCurrency~</currency>
                            <amount>~value~</amount>
                            <custom-attributes>
                                  <custom-attribute attribute-id="endDate">~enddate~</custom-attribute>
                                  <custom-attribute attribute-id="locale">~staticLocale~</custom-attribute>
                                  <custom-attribute attribute-id="siteID">~staticSiteId~</custom-attribute>
                            </custom-attributes>
                        </gift-certificate>
                
                XML_BODY)

            ->setSuffix('</gift-certificates>')

            ->noNewLine()
        ;
    }


    public function brand()
    {
        return $this->brand;
    }

    public function certMessage()
    {
        return $this->message;
    }

    public function certDescription()
    {
        return $this->description;
    }

    public function enddate()
    {
        return $this->endDate;
    }

    public function staticCurrency()
    {
        return $this->currency;
    }

    public function staticLocale()
    {
        return $this->locale;
    }

    public function staticSiteId()
    {
        return $this->siteId;
    }

    public function randomcode()
    {
        $random = substr(str_replace('.','',microtime(true)),-11);
        if(strlen($random) < 1) {
            die($random);
        }
        return $this->codePrefix . $random;
    }
}
