<?php
/**

 */

class createShipping extends Script
{
    public function getModel()
    {
        return (new FfcModel())
            ->addFilenames('shipping.csv', 'shipping.sql')

            ->addStatement("INSERT IGNORE INTO config_shipping (`brand`,`locale`,`frontend_code`,`name`,`description`,`dispatch_description`) " .
                            "VALUES ('~brand~','~territory~','~frontend_code~','~name~','~description~','~dispatch_description~');")
        ;
    }

    public function territory($row)
    {
        return strtolower(substr($row['locale'], -2));
    }
}
