<?php
/**
 * Adds a random code colum to a giftcert csv
 */

class createGiftcertCsv extends Script
{
    private $input = 'laybuy.csv';
    private $output = 'laybuy_giftcerts.csv';
    private $message = "Hey there. Thanks for being part of Laybuy Day! We've now credited the value of one of your payments to your boohoo account. ";
    private $brand = 'Boohoo';
    private $codePrefix = "LB072020";
    private $expiry = '365';
    private $currency = 'GBP';
    private $locale = 'en_GB';
    private $siteId = 'boohoo-UK';
    private $campaignName = 'Laybuy072020';
    private $campaignPrefix = 'LBY';

    private static $number;

    public function getModel()
    {
        return (new FfcModel())

            ->addFilenames($this->input, $this->output)

            ->setPrefix('customer_email_address,customer_name,giftcert_value,giftcert_message,site_id,locale,currency,sender_name,expiry_days,campaign_name,campaign_prefix,code')

            ->addStatement('~email_address~,~customer_name~,~value~,~certMessage~,~staticSiteId~,' .
                            '~staticLocale~,~staticCurrency~,~brand~,~expiry~,~campaignName~,~campaignPrefix~,~randomcode~')

        ;
    }

    public function randomcode()
    {
        if(!self::$number) {
            self::$number=rand(11111111111,99999999999);
        }
        self::$number += rand(10,100);
        $number = substr((string)self::$number,-11);
        return $this->codePrefix . $number;
    }

    public function brand()
    {
        return $this->brand;
    }

    public function certMessage()
    {
        return $this->message;
    }

    public function certDescription()
    {
        return $this->description;
    }

    public function enddate()
    {
        return $this->endDate;
    }

    public function staticCurrency()
    {
        return $this->currency;
    }

    public function staticLocale()
    {
        return $this->locale;
    }

    public function staticSiteId()
    {
        return $this->siteId;
    }

    public function expiry()
    {
        return $this->expiry;
    }

    public function campaignName()
    {
        return $this->campaignName;
    }

    public function campaignPrefix()
    {
        return $this->campaignPrefix;
    }

}
